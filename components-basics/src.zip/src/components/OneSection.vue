<template>
  <section class="box">
    <h4>ひとつのコンポーネント</h4>
    <p>コンポーネントとは、</p>
  </section>
</template>

<style scoped>
.box {
  border: green 1px solid;
  margin: 10px;
}
</style>
